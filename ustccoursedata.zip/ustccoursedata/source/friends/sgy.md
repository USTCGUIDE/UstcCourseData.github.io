---
wiki: friends
menu_id: friends
title: SGY | 少年班学院 校友
---

这里本应记载着一些来自少年班学院的校友们