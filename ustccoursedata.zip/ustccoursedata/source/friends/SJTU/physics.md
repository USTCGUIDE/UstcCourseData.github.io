---
wiki: friends
menu_id: friends
title: SJTU-Physics | 上海交通大学-物理学专业 校友
---

这里本应记载着一些来自上海交通大学物理学专业的朋友们