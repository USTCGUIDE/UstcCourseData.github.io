---
title: intro
date: 2024-04-26 19:49:12
tags:
---

Welcome to 200! This is our homepage: [Homepage](https://alice-shimada.github.io)!

```python
print("Hello, 200!")
```